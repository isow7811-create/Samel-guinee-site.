// Endpoint réservé à l'administration. L'accès SQL RLS autorise uniquement les comptes présents dans profiles.
import {createClient} from "https://esm.sh/@supabase/supabase-js@2";
Deno.serve(async req=>{
 const supabase=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_ANON_KEY")!,{global:{headers:{Authorization:req.headers.get("Authorization")||""}}});
 const {data:{user}}=await supabase.auth.getUser();if(!user)return new Response("Unauthorized",{status:401});
 const {id,updates}=await req.json();
 const allowed=["nom","prenom","sexe","region_commune","emplacement","telephone","numero_pdv","maison_distribution","poste_occupe"];
 const safe=Object.fromEntries(Object.entries(updates||{}).filter(([k])=>allowed.includes(k)));
 const {error}=await supabase.from("members").update({...safe,updated_at:new Date().toISOString()}).eq("id",id);
 return new Response(JSON.stringify({ok:!error,error:error?.message}),{status:error?400:200,headers:{"Content-Type":"application/json"}});
});
