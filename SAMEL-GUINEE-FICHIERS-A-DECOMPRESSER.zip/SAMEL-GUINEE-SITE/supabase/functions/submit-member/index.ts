import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors={ "Access-Control-Allow-Origin":"*", "Access-Control-Allow-Headers":"authorization, x-client-info, apikey, content-type" };
Deno.serve(async req=>{
 if(req.method==="OPTIONS") return new Response("ok",{headers:cors});
 try{
  const form=await req.formData(); const required=["nom","prenom","sexe","region_ville_commune","emplacement","telephone","numero_pdv"];
  const v:any={}; for(const k of required){v[k]=String(form.get(k)||"").trim();if(!v[k])throw new Error("Champ obligatoire manquant: "+k);}
  v.poste_occupe=String(form.get("poste_occupe")||"").trim()||null;
  const old=String(form.get("numero_existant")||"").trim();v.numero_existant=old?Number(old):null;
  if(v.numero_existant!==null && (!Number.isInteger(v.numero_existant)||v.numero_existant<1||v.numero_existant>21))throw new Error("Les numéros déjà attribués 1 à 21 sont saisis par l'administration.");
  const photo=form.get("selfie");if(!(photo instanceof File)||photo.size>5242880||!["image/jpeg","image/png","image/webp"].includes(photo.type))throw new Error("Selfie invalide (JPEG, PNG ou WebP, 5 Mo maximum).");
  const admin=createClient(Deno.env.get("SUPABASE_URL")!,Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const {data:numberData,error:numberError}=await admin.rpc("allocate_member_number");
  if(numberError)throw numberError;
  const memberNumber=numberData as number;
  const path=`${memberNumber}/${crypto.randomUUID()}.${photo.type.split("/")[1]}`;
  const {error:uploadError}=await admin.storage.from("member-selfies").upload(path,photo,{contentType:photo.type,upsert:false});
  if(uploadError)throw uploadError;
  const {error:insertError}=await admin.from("members").insert({...v,member_number:memberNumber,selfie_path:path});
  if(insertError){await admin.storage.from("member-selfies").remove([path]);throw insertError;}
  const {data:selfieLink}=await admin.storage.from("member-selfies").createSignedUrl(path,60*60*24*7);
  const emailHtml=`<h2>Nouvelle identification SAMEL-Guinée</h2><p>Numéro membre : <b>${memberNumber}</b></p><p>Nom : ${v.nom} ${v.prenom}</p><p>Sexe : ${v.sexe}</p><p>Téléphone : ${v.telephone}</p><p>Région / Ville / Commune : ${v.region_ville_commune}</p><p>Emplacement : ${v.emplacement}</p><p>PDV : ${v.numero_pdv}</p><p>Selfie : <a href="${selfieLink?.signedUrl||"#"}">Voir le selfie (lien valable 7 jours)</a></p>`;
  const mail=await fetch("https://api.resend.com/emails",{method:"POST",headers:{"Authorization":`Bearer ${Deno.env.get("RESEND_API_KEY")}`,"Content-Type":"application/json"},body:JSON.stringify({from:Deno.env.get("MAIL_FROM"),to:["samelguinee224@gmail.com"],subject:`Nouvelle inscription SAMEL-Guinée — N° ${memberNumber}`,html:emailHtml})});
  if(!mail.ok) console.error("Resend error",await mail.text());
  return new Response(JSON.stringify({member_number:memberNumber,email_notification:mail.ok}),{headers:{...cors,"Content-Type":"application/json"}});
 }catch(e){return new Response(JSON.stringify({error:e.message}),{status:400,headers:{...cors,"Content-Type":"application/json"}});}
});
